/**
 * Чистый модуль расчётов «ТарифДетокс».
 * Без зависимостей от DOM. Полностью покрывается модульными тестами.
 */

const LNR_REGIONS = new Set([
  'Луганск',
  'Алчевск',
  'Краснодон',
  'Свердловск',
  'Стаханов',
  'Ровеньки',
  'Антрацит',
  'Брянка',
  'Красный Луч',
  'Северодонецк',
  'Лисичанск',
  'Рубежное',
  'Первомайск',
  'Все города ЛНР',
  'Луганская Народная Республика (ЛНР)'
]);

function isAllLnrRegion(region) {
  return region === 'Все города ЛНР' || region === 'Луганская Народная Республика (ЛНР)';
}

export function isTariffAvailableInRegion(tariffRegion, userRegion) {
  if (tariffRegion === userRegion) return true;
  if (tariffRegion === 'Все регионы' || userRegion === 'Все регионы') return true;
  if (isAllLnrRegion(tariffRegion) && LNR_REGIONS.has(userRegion)) return true;
  if (isAllLnrRegion(userRegion) && LNR_REGIONS.has(tariffRegion)) return true;
  return false;
}

/**
 * Расчёт полной стоимости владения (TCO) тарифа связи за 12 месяцев с учётом акций и платы за подключение.
 * @param {Object} tariff - Объект тарифа
 * @param {Object} [options] - Дополнительные параметры (например, плата за аренду роутера)
 * @returns {{ tco12: number, effectiveMonthly: number, promoSavings: number }}
 */
export function calculateTariffTCO12(tariff, options = {}) {
  const setupFee = Number(tariff.setupFee) || 0;
  const regularPrice = Number(tariff.monthlyPrice) || 0;
  const promoMonths = Math.min(12, Math.max(0, Number(tariff.promoDurationMonths) || 0));
  const hasPromo = promoMonths > 0 && tariff.promoMonthlyPrice !== null && tariff.promoMonthlyPrice !== undefined;
  const promoPrice = hasPromo ? Number(tariff.promoMonthlyPrice) : regularPrice;

  const regularMonths = 12 - promoMonths;
  const baseServiceCost = (promoPrice * promoMonths) + (regularPrice * regularMonths);

  // Аренда оборудования (для интернета)
  const routerRentMonthly = options.needsRouter ? (Number(tariff.routerRentMonthly) || 0) : 0;
  const equipmentCost = routerRentMonthly * 12;

  const tco12 = setupFee + baseServiceCost + equipmentCost;
  const effectiveMonthly = Math.round(tco12 / 12);

  // Сколько пользователь экономит благодаря промо-периоду за год
  const standardAnnualCost = (regularPrice * 12) + equipmentCost + setupFee;
  const promoSavings = Math.max(0, standardAnnualCost - tco12);

  return {
    tco12,
    effectiveMonthly,
    promoSavings,
    promoMonths,
    hasPromo,
    promoPrice,
    regularPrice,
    setupFee,
    equipmentCost
  };
}

/**
 * Подбор наиболее выгодного мобильного тарифа.
 * @param {Object} user - Потребности пользователя { currentPrice, gb, minutes, sms, region, currentOperator }
 * @param {Array} tariffs - Список тарифов из базы данных
 * @returns {Object} Результат сравнения
 */
export function findBestMobileTariff(user, tariffs = []) {
  const currentMonthly = Math.max(0, Number(user.currentPrice) || 0);
  const currentAnnualTCO = currentMonthly * 12;

  const isUnlimitedGb = Boolean(user.isUnlimitedGb || user.unlimitedGb || Number(user.gb) >= 999);
  const isUnlimitedMin = Boolean(user.isUnlimitedMinutes || user.unlimitedMinutes || Number(user.minutes) >= 5000);
  const isUnlimitedSms = Boolean(user.isUnlimitedSms || user.unlimitedSms);

  const userGb = isUnlimitedGb ? 9999 : (Number(user.gb) || 0);
  const userMin = isUnlimitedMin ? 9999 : (Number(user.minutes) || 0);
  const userSms = isUnlimitedSms ? 100 : (Number(user.sms) || 0);
  const userRegion = user.region || 'Все города ЛНР';

  // Фильтруем тарифы по региону
  const regionalTariffs = tariffs.filter(t => isTariffAvailableInRegion(t.region, userRegion));

  // Строгое соответствие критериям
  const matchingTariffs = regionalTariffs.filter(t => {
    const gbMatch = isUnlimitedGb
      ? (Boolean(t.isUnlimitedGb) || Number(t.includedGb) >= 999)
      : (Number(t.includedGb) >= userGb);

    const minMatch = isUnlimitedMin
      ? (Boolean(t.isUnlimitedMinutes) || Number(t.includedMinutes) >= 1500)
      : (Number(t.includedMinutes) >= userMin);

    const smsMatch = userSms === 0 || Number(t.includedSms) >= userSms;

    return gbMatch && minMatch && smsMatch;
  });

  // Подбор близких тарифов (по максимальному объёму пакетов и выгодности)
  const scoredRegional = regionalTariffs.map(t => {
    const tco = calculateTariffTCO12(t);
    const tGb = Boolean(t.isUnlimitedGb) ? 9999 : (Number(t.includedGb) || 0);
    const tMin = Boolean(t.isUnlimitedMinutes) ? 9999 : (Number(t.includedMinutes) || 0);

    const targetGb = isUnlimitedGb ? 100 : Math.max(1, userGb);
    const targetMin = isUnlimitedMin ? 1000 : Math.max(1, userMin);

    const gbRatio = Math.min(2.0, tGb / targetGb);
    const minRatio = Math.min(2.0, tMin / targetMin);
    const unlimBonus = (t.isUnlimitedGb ? 1.0 : 0) + (t.isUnlimitedMinutes ? 0.5 : 0);
    const appsBonus = (Array.isArray(t.unlimitedApps) && t.unlimitedApps.length > 0) ? (t.unlimitedApps.length * 0.1) : 0;
    const priceScore = Math.max(0.1, 1 - (tco.tco12 / 15000));

    const proximityScore = (gbRatio * 0.45) + (minRatio * 0.35) + unlimBonus + appsBonus + (priceScore * 0.2);

    return {
      tariff: t,
      ...tco,
      proximityScore,
      savingsYear: currentAnnualTCO - tco.tco12,
      savingsMonth: Math.round((currentAnnualTCO - tco.tco12) / 12)
    };
  });

  scoredRegional.sort((a, b) => b.proximityScore - a.proximityScore || a.tco12 - b.tco12);

  // Выбираем до 3 близких альтернатив от разных операторов
  const closestTariffs = [];
  const seenOps = new Set();
  for (const item of scoredRegional) {
    if (!seenOps.has(item.tariff.operator) || seenOps.size >= 3) {
      closestTariffs.push(item);
      seenOps.add(item.tariff.operator);
      if (closestTariffs.length >= 3) break;
    }
  }

  // Если нет точного совпадения по критериям
  if (matchingTariffs.length === 0) {
    return {
      hasMatch: false,
      isClosestMatch: true,
      currentMonthly,
      currentAnnualTCO,
      bestTariff: closestTariffs.length > 0 ? closestTariffs[0].tariff : null,
      savingsYear: 0,
      savingsMonth: 0,
      isCurrentOptimal: true,
      closestTariffs,
      allAlternatives: scoredRegional,
      reason: 'В базе нет тарифов, которые одновременно полностью покрывают все заданные максимальные критерии. Ниже представлены наиболее близкие тарифы с максимальными пакетами.'
    };
  }

  // Считаем TCO для каждого подходящего тарифа
  const scored = matchingTariffs.map(t => {
    const tco = calculateTariffTCO12(t);
    return {
      tariff: t,
      ...tco,
      savingsYear: currentAnnualTCO - tco.tco12,
      savingsMonth: Math.round((currentAnnualTCO - tco.tco12) / 12)
    };
  });

  // Сортируем: сначала максимальная экономия (минимальный TCO)
  scored.sort((a, b) => a.tco12 - b.tco12);
  const best = scored[0];

  // Другие варианты от разных операторов для выбора
  const otherOptions = [];
  const usedOtherOps = new Set([best.tariff.operator]);
  for (let i = 1; i < scored.length; i++) {
    const opt = scored[i];
    if (!usedOtherOps.has(opt.tariff.operator)) {
      otherOptions.push(opt);
      usedOtherOps.add(opt.tariff.operator);
    }
    if (otherOptions.length >= 2) break;
  }
  if (otherOptions.length < 2) {
    for (let i = 1; i < scored.length; i++) {
      if (!otherOptions.includes(scored[i])) {
        otherOptions.push(scored[i]);
        if (otherOptions.length >= 2) break;
      }
    }
  }

  // Проверка: выгоден ли новый тариф
  if (best.savingsYear > 0) {
    return {
      hasMatch: true,
      isClosestMatch: false,
      currentMonthly,
      currentAnnualTCO,
      bestTariff: best.tariff,
      tco12: best.tco12,
      effectiveMonthly: best.effectiveMonthly,
      savingsYear: best.savingsYear,
      savingsMonth: best.savingsMonth,
      isCurrentOptimal: false,
      allAlternatives: scored,
      otherOptions,
      closestTariffs
    };
  }

  // Если текущий тариф дешевле или равен лучшей альтернативе
  return {
    hasMatch: true,
    isClosestMatch: false,
    currentMonthly,
    currentAnnualTCO,
    bestTariff: best.tariff,
    tco12: best.tco12,
    effectiveMonthly: best.effectiveMonthly,
    savingsYear: 0,
    savingsMonth: 0,
    isCurrentOptimal: true,
    allAlternatives: scored,
    otherOptions,
    closestTariffs,
    reason: 'Ваш текущий тариф уже выгоднее или равен лучшим предложениям на рынке!'
  };
}

/**
 * Подбор наиболее выгодного тарифа домашнего интернета.
 * @param {Object} user - { currentPrice, minSpeedMbps, needsRouter, region, currentOperator }
 * @param {Array} tariffs - Список тарифов
 * @returns {Object}
 */
export function findBestInternetTariff(user, tariffs = []) {
  const baseMonthly = Math.max(0, Number(user.currentPrice) || 0);
  const currentRouterRent = Math.max(0, Number(user.currentRouterRent) || 0);
  const currentMonthly = baseMonthly + currentRouterRent;
  const currentAnnualTCO = currentMonthly * 12;
  const userSpeed = Number(user.minSpeedMbps) || 100;
  const userRegion = user.region || 'Все города ЛНР';
  const needsRouter = Boolean(user.needsRouter);

  // Фильтруем тарифы по региону
  const regionalTariffs = tariffs.filter(t => isTariffAvailableInRegion(t.region, userRegion));

  const matchingTariffs = regionalTariffs.filter(t => {
    return Number(t.speedMbps) >= userSpeed;
  });

  // Оценка близости альтернативных интернет-тарифов
  const scoredRegional = regionalTariffs.map(t => {
    const tco = calculateTariffTCO12(t, { needsRouter });
    const speedRatio = Math.min(2.0, (Number(t.speedMbps) || 100) / userSpeed);
    const tvBonus = t.hasTv ? 0.2 : 0;
    const priceScore = Math.max(0.1, 1 - (tco.tco12 / 12000));
    const proximityScore = (speedRatio * 0.5) + tvBonus + (priceScore * 0.3);

    return {
      tariff: t,
      ...tco,
      proximityScore,
      savingsYear: currentAnnualTCO - tco.tco12,
      savingsMonth: Math.round((currentAnnualTCO - tco.tco12) / 12)
    };
  });

  scoredRegional.sort((a, b) => b.proximityScore - a.proximityScore || a.tco12 - b.tco12);

  // Выбираем до 3 близких альтернатив от разных провайдеров
  const closestTariffs = [];
  const seenOps = new Set();
  for (const item of scoredRegional) {
    if (!seenOps.has(item.tariff.operator) || seenOps.size >= 3) {
      closestTariffs.push(item);
      seenOps.add(item.tariff.operator);
      if (closestTariffs.length >= 3) break;
    }
  }

  if (matchingTariffs.length === 0) {
    return {
      hasMatch: false,
      isClosestMatch: true,
      currentMonthly,
      currentAnnualTCO,
      bestTariff: closestTariffs.length > 0 ? closestTariffs[0].tariff : null,
      savingsYear: 0,
      savingsMonth: 0,
      isCurrentOptimal: true,
      closestTariffs,
      allAlternatives: scoredRegional,
      reason: 'В базе нет тарифов с такой высокой скоростью в вашем городе. Ниже представлены наиболее скоростные альтернативы.'
    };
  }

  const scored = matchingTariffs.map(t => {
    const tco = calculateTariffTCO12(t, { needsRouter });
    return {
      tariff: t,
      ...tco,
      savingsYear: currentAnnualTCO - tco.tco12,
      savingsMonth: Math.round((currentAnnualTCO - tco.tco12) / 12)
    };
  });

  scored.sort((a, b) => a.tco12 - b.tco12);
  const best = scored[0];

  // Другие варианты от разных провайдеров
  const otherOptions = [];
  const usedOps = new Set([best.tariff.operator]);
  for (let i = 1; i < scored.length; i++) {
    const opt = scored[i];
    if (!usedOps.has(opt.tariff.operator)) {
      otherOptions.push(opt);
      usedOps.add(opt.tariff.operator);
    }
    if (otherOptions.length >= 2) break;
  }
  if (otherOptions.length < 2) {
    for (let i = 1; i < scored.length; i++) {
      if (!otherOptions.includes(scored[i])) {
        otherOptions.push(scored[i]);
        if (otherOptions.length >= 2) break;
      }
    }
  }

  if (best.savingsYear > 0) {
    return {
      hasMatch: true,
      isClosestMatch: false,
      currentMonthly,
      currentAnnualTCO,
      bestTariff: best.tariff,
      tco12: best.tco12,
      effectiveMonthly: best.effectiveMonthly,
      savingsYear: best.savingsYear,
      savingsMonth: best.savingsMonth,
      isCurrentOptimal: false,
      allAlternatives: scored,
      otherOptions,
      closestTariffs
    };
  }

  return {
    hasMatch: true,
    isClosestMatch: false,
    currentMonthly,
    currentAnnualTCO,
    bestTariff: best.tariff,
    tco12: best.tco12,
    effectiveMonthly: best.effectiveMonthly,
    savingsYear: 0,
    savingsMonth: 0,
    isCurrentOptimal: true,
    allAlternatives: scored,
    otherOptions,
    closestTariffs,
    reason: 'Ваш текущий тариф домашнего интернета уже оптимален.'
  };
}

/**
 * Расчёт расходов и оптимизации подписок.
 * @param {Array} selectedIds - Выбранные идентификаторы подписок
 * @param {Array} customItems - Пользовательские подписки [{ name, price, unused }]
 * @param {Array} unusedIds - Идентификаторы подписок, помеченных как «не пользуюсь»
 * @param {Array} duplicatesFound - Найденные дубликаты { duplicateService, bundledInside, reason }
 * @param {Array} dbSubscriptions - База всех подписок
 * @returns {Object}
 */
export function calculateSubscriptionsSummary({
  selectedIds = [],
  customItems = [],
  unusedIds = [],
  duplicatesFound = [],
  dbSubscriptions = []
}) {
  const dbMap = new Map(dbSubscriptions.map(s => [s.id, s]));
  
  let currentMonthlyTotal = 0;
  const activeItems = [];
  const unusedSet = new Set(unusedIds);
  const duplicateIdSet = new Set(duplicatesFound.map(d => d.duplicateId).filter(Boolean));

  // Обработка стандартных подписок из базы
  for (const id of selectedIds) {
    const sub = dbMap.get(id);
    if (!sub) continue;
    const price = Number(sub.monthlyPrice) || 0;
    currentMonthlyTotal += price;

    const isUnused = unusedSet.has(id);
    const isDuplicate = duplicateIdSet.has(id);

    activeItems.push({
      id: sub.id,
      name: sub.name,
      monthlyPrice: price,
      annualPrice: sub.annualPrice || null,
      isUnused,
      isDuplicate,
      cancelUrl: sub.cancelUrl,
      refundPolicyTip: sub.refundPolicyTip,
      category: sub.category
    });
  }

  // Пользовательские добавленные подписки
  for (const item of customItems) {
    const price = Math.max(0, Number(item.price) || 0);
    currentMonthlyTotal += price;
    const isUnused = Boolean(item.unused);

    activeItems.push({
      id: `custom-${Math.random().toString(36).substring(2, 7)}`,
      name: item.name || 'Своя подписка',
      monthlyPrice: price,
      annualPrice: null,
      isUnused,
      isDuplicate: false,
      cancelUrl: null,
      refundPolicyTip: null,
      category: 'custom'
    });
  }

  // Расчёт экономии:
  // 1. Отказ от неиспользуемых
  let unusedMonthlySavings = 0;
  for (const item of activeItems) {
    if (item.isUnused) {
      unusedMonthlySavings += item.monthlyPrice;
    }
  }

  // 2. Отказ от дубликатов (если они уже не посчитаны в unused)
  let duplicateMonthlySavings = 0;
  for (const item of activeItems) {
    if (item.isDuplicate && !item.isUnused) {
      duplicateMonthlySavings += item.monthlyPrice;
    }
  }

  // 3. Выгода при переходе на годовой тариф (для оставшихся нужных)
  let annualPlanSavingsYear = 0;
  const annualPlanRecommendations = [];
  for (const item of activeItems) {
    if (!item.isUnused && !item.isDuplicate && item.annualPrice) {
      const yearCostMonthly = item.monthlyPrice * 12;
      const yearCostAnnual = item.annualPrice;
      if (yearCostAnnual < yearCostMonthly) {
        const diff = yearCostMonthly - yearCostAnnual;
        annualPlanSavingsYear += diff;
        annualPlanRecommendations.push({
          name: item.name,
          diffYear: diff,
          monthlyEquivalent: Math.round(yearCostAnnual / 12)
        });
      }
    }
  }

  const totalMonthlyDirectSavings = unusedMonthlySavings + duplicateMonthlySavings;
  const totalAnnualSavings = (totalMonthlyDirectSavings * 12) + annualPlanSavingsYear;

  return {
    currentMonthlyTotal,
    currentAnnualTotal: currentMonthlyTotal * 12,
    activeItems,
    unusedMonthlySavings,
    duplicateMonthlySavings,
    annualPlanSavingsYear,
    annualPlanRecommendations,
    totalMonthlySavings: Math.round(totalAnnualSavings / 12),
    totalAnnualSavings
  };
}

/**
 * Итоговая сводка по всем категориям расходов.
 */
export function calculateGrandTotal({ mobileResult, internetResult, subsResult }) {
  const mobileCur = mobileResult ? mobileResult.currentMonthly : 0;
  const internetCur = internetResult ? internetResult.currentMonthly : 0;
  const subsCur = subsResult ? subsResult.currentMonthlyTotal : 0;

  const currentMonthlyGrand = mobileCur + internetCur + subsCur;
  const currentAnnualGrand = currentMonthlyGrand * 12;

  const mobileSavingYear = mobileResult ? mobileResult.savingsYear : 0;
  const internetSavingYear = internetResult ? internetResult.savingsYear : 0;
  const subsSavingYear = subsResult ? subsResult.totalAnnualSavings : 0;

  const totalAnnualSavings = mobileSavingYear + internetSavingYear + subsSavingYear;
  const totalMonthlySavings = Math.round(totalAnnualSavings / 12);
  const optimizedMonthlyGrand = Math.max(0, currentMonthlyGrand - totalMonthlySavings);

  return {
    currentMonthlyGrand,
    currentAnnualGrand,
    optimizedMonthlyGrand,
    totalAnnualSavings,
    totalMonthlySavings,
    hasAnySavings: totalAnnualSavings > 0,
    breakdown: {
      mobile: {
        current: mobileCur,
        savingsYear: mobileSavingYear,
        isOptimal: mobileResult ? mobileResult.isCurrentOptimal : true
      },
      internet: {
        current: internetCur,
        savingsYear: internetSavingYear,
        isOptimal: internetResult ? internetResult.isCurrentOptimal : true
      },
      subscriptions: {
        current: subsCur,
        savingsYear: subsSavingYear
      }
    }
  };
}
